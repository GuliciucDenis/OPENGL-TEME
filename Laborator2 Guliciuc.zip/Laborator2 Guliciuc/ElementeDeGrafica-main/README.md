# Requirements

1. Visual Studio Code 2022
2. DotNet Framework 4.8.x - runtime + SDK

# ATENTIE!
Rularea proiectului pe mai mult de un monitor provoaca niste probleme
(cubul nu apare) #TODO - fix cube render on multiple monitors.

# Laborator 2
Modificarea viewportului definește suprafața pe care proiecția scenei 3D va avea loc.

-Un viewport permite utilizatorului să simuleze o cameră pentru a viziona obiectele create din diferite unghiuri.
-Conceptul de cadre pe secundă reprezintă numărul de cadre afișate într-o secundă de program.
-Metoda OnUpdateFrame() este rulată o dată după inițializarea OnLoad(), apoi repetată în funcție de numărul specificat de cadre pe secundă.
-În modul imediat de randare, aplicația trimite comenzi grafice direct către GPU pentru fiecare obiect sau detaliu individual care trebuie desenat pe ecran.
-Începând cu versiunea OpenGL 3.0, modul imediat nu mai este suportat; prin urmare, o versiune recomandată este OpenGL 2.1.
-OnRenderFrame() este rulată după fiecare OnUpdateFrame sau repetată în funcție de numărul de cadre pe secundă.
-OnResize() trebuie rulată cel puțin o dată pentru a adapta fereastra noastră la dimensiunea ecranului.
-Parametrii metodei CreatePerspectiveFieldOfView() sunt:
a- fieldOfView - câmpul de vedere între 0 și 180 de grade
b- aspectRatio - raportul dintre lățimea și lungimea ferestrei, poate lua orice valoare reală.

